(()=>{var o=typeof browser<"u"?browser:chrome;function s(){document.querySelectorAll("[data-i18n]").forEach(e=>{let n=e.getAttribute("data-i18n"),t=o.i18n.getMessage(n);t&&(e.textContent=t)})}document.addEventListener("DOMContentLoaded",()=>{s()});})();
//# sourceMappingURL=onboarding.js.map
